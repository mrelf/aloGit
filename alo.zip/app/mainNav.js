//main nav controllers
taskManager.controller('CreateTaskController', function($scope){
    $scope.message = 'Create a new task';
});

taskManager.controller('InProgressController', function($scope){
    $scope.message = 'In progress';
});

taskManager.controller('ParkedOutController', function($scope){
    $scope.message = 'parked out';
});

taskManager.controller('BacklogController', function($scope){
    $scope.message = 'backlog';
});

//set active nav menu
taskManager.directive('setActiveMenu', function($location){
    return function(scope, element, attrs){
        
        //variabila pentru toate linkurile
        var links = element.find('a'),
        
        //variabila pentru a stoca linkul intr`un obiect
            link,
            
        //variabila pentru a tine url ul linkului
            url,
            
        //obiect pentru a tine url linkurilor
            urlMap = {},
            
        //variabila pentru linkul curent
            currentLink,
            
        //variabila ce seteaza clasa aferenta elemtnului activ
            onClass = attrs.setActiveMenu || 'on',
                
        //variable for iterating over links
            i;
        
        //collect link urls inside the urlMap object
        for(i = 0; i < links.length; i++){
            link = angular.element(links[i]);
            url = link.attr('href');
            urlMap[url] = url;
        };
        console.log(urlMap);
        
        
    }
});